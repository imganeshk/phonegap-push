## Supported Platforms

- Cordova CLI (3.6.3 or newer)
- Android (`cordova-android` 4.0.0 or higher)
- Browser
- iOS (`cordova-ios` 4.1.0 or higher)
- Windows Universal (not Windows Phone 8)
